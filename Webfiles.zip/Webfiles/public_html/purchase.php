<?php
error_reporting(1);
require 'config.php';
require 'db.php';
require 'vendor/autoload.php';

if (isset($_GET['id'])) {
    $paymentId = $_GET['id'];

    $billPayments = new Qiwi\Api\BillPayments($SECRET_KEY);
    $response = $billPayments->getBillInfo($paymentId);

    if (isset($response) && $response['status']['value'] == 'PAID') {
        $billDB = $pdo->prepare("SELECT * FROM license_keys WHERE purchased_id=? LIMIT 1");
        $billDB->execute([$response['billId']]);
        $billDB = $billDB->fetch();

        if(!isset($billDB['purchased_id'])) {
            $purchased_id = "UPDATE license_keys SET purchased_id=? WHERE status = 0 AND banned = 0 AND cheat=? AND purchased_id=0 LIMIT 1";
            $purchased_id= $pdo->prepare($purchased_id);
            $purchased_id->execute([$response['billId'], $response['customFields']['product_name']]);
        }

        $key = $pdo->prepare("SELECT license_key FROM license_keys WHERE purchased_id =? LIMIT 1");
        $key->execute([$response['billId']]);
        $key = $key->fetch()['license_key'];
    } else {
        header('Location: /');
    }
} else {
    header('Location: /');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UMBRELLA</title>
    <link rel="stylesheet" href="css/index.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/favicon.png" type="image/x-icon">
</head>
<body>
<header class="header">
    <div class="container">
        <h1 class="header-title">pizdechook</h1>
    </div>
</header>
<main class="main">
    <div class="purchase">
        <div class="container">
            <h1 class="purchase-title">Спасибо за покупку.</h1>
            <label class="purchase-code">
                <p>Ваш ключ</p>
                <input value="<?php echo $key; ?>" readonly disabled>
            </label>
            <div class="purchase-info">
                <p class="download">Скачать Loader: <a href="https://pizdechook.pw/download.php/">(Нажми на меня)</a></p>
                <p class="description">Инструкция <br/> 1) Скопируйте ключ. <br/> 2) Выберете в лоудере игру (Rust - 1). <br/> 3) Введите ключ в лоудере. <br/> 4) Дождитесь активации ключа. <br/> 5) Веселитесь. 
<br/><br/><br/><br/> 


            </div>
        </div>
    </div>
</main>
</body>
</html>
