<?php
Header('Location: https://www.virustotal.com/gui/file/f657b9575b4d8789eb640073d9ccf031d2ecdd3dd389a0c16e659f96a70b3e24/detection');
?>