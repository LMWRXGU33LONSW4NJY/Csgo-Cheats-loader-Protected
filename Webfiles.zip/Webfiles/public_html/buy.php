<?php
header('Content-Type: application/json');
require 'config.php';
require 'vendor/autoload.php';
include_once 'product.php'; global $products;

if(isset($_POST['id'])) {
    $product = $products[$_POST['id']];

    if($product) {
        $billPayments = new Qiwi\Api\BillPayments($SECRET_KEY);
        $billId = rand(1000000000, 9999999999);

        $params = [
            'publicKey' => $publicKey,
            'amount' => $product['price'],
            'billId' => $billId,
            'comment' => 'PaymentID: ' . $billId,
            'customFields' => [
                'themeCode' => "Ygnatyi-NuJ0GWBJTz",
                'product_name' => $product['db_name'],
            ],
            'successUrl' => $_SERVER['SERVER_NAME'] . '/purchase?id='.$billId,
        ];

        /** @var \Qiwi\Api\BillPayments $billPayments */
        $link = $billPayments->createPaymentForm($params);

        $response = array(
            "status" => true,
            "pay_link" => $link,
        );

        echo json_encode($response, JSON_FORCE_OBJECT); // Ответ
    }
}