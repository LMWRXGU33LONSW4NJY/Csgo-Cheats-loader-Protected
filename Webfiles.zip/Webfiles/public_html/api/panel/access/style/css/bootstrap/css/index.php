<?php
if( !defined("IN_PAGE") )
{
	header("location: https://www.google.ru/");
	die();
}
?>