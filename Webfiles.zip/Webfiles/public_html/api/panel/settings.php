<?php
define("HOST","localhost");
define("USER","sharawin_client");
define("DB","sharawin_client");
define("PASS","m%0dPGIw");
?>