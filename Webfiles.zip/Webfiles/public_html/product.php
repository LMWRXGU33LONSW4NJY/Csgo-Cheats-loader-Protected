<?php

// db_name - название чита в базе
// name - названеи чита
// description - описание
// price - цена

// By webxdev

$products = [
    [
        'db_name' => 'Rust 1 Day',
        'name' => 'Rust 1 Day',
        'duration' => '/ Day',
        'description' => 'Rust: 1 Day',
        'price' => 50,
    ],
    [
        'db_name' => 'Rust 30 Days',
        'name' => 'Rust 30 Days',
        'duration' => '/ Month',
        'description' => 'Rust: 30 days',
        'price' => 100,
    ],
];